#ifndef ELECTRICVEHICLETYPE_H
#define ELECTRICVEHICLETYPE_H

#include <landVehicleType.h>


class electricVehicleType : public landVehicleType
{
    public:
        electricVehicleType();
        virtual ~electricVehicleType();

    protected:

    private:
};

#endif // ELECTRICVEHICLETYPE_H
