#ifndef ICEVEHICLETYPE_H
#define ICEVEHICLETYPE_H

#include <landVehicleType.h>


class iceVehicleType : public landVehicleType
{
    public:
        iceVehicleType();
        virtual ~iceVehicleType();

    protected:

    private:
};

#endif // ICEVEHICLETYPE_H
