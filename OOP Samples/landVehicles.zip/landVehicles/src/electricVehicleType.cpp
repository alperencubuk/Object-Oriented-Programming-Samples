#include "electricVehicleType.h"

electricVehicleType::electricVehicleType()
{
    //ctor
}

electricVehicleType::~electricVehicleType()
{
    //dtor
}
