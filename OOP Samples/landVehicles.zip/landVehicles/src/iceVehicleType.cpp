#include "iceVehicleType.h"

iceVehicleType::iceVehicleType()
{
    //ctor
}

iceVehicleType::~iceVehicleType()
{
    //dtor
}
